<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "theyhtreeg";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$dob = $_POST['dob'];
// Insert data into database
$sql = "INSERT INTO users (name, email, address, phone, dob) VALUES ('$name',
'$email', '$address', '$phone', '$dob')";
if ($conn->query($sql) === TRUE) {
echo "user created successfully";
} else {
echo "Error: user not created " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>